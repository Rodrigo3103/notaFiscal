from pathlib import Path


# Cria o texto da nota fiscal que será salvo
textoNotaFiscal = f"""[Emitente]
CRT = 3
CNPJCPF = {'cnpj'}
xNome = {'razaoSocial'}
xFant = {'nomeFantasia'}
IE =  {'ie'}
xLgr = {'endereco'}
nro = {'numero'}
xCpl = {'complemento'}
xBairro = {'bairro'}
cMun = {'codCidade'}
xMun = {'cidade'}
cUF = {'35'}
UF = {'uf'}
CEP = {'cep'}
cPais = {'1058'}
xPais = {'BRASIL'}
Fone = {'telefone'}"""
# Criação/gravação do arquivo email.txt
with open("NotaFiscal/configuracoes.txt", "w") as arquivo:
    arquivo.write(textoNotaFiscal)
    arquivo.close()